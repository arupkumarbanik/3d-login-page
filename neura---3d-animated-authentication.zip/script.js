/**
 * NEURA - 3D Animated Authentication Engine
 * Pure Vanilla JavaScript (ES6+) - 60 FPS Parallax, 3D Transitions & Form Validation
 */

(() => {
  'use strict';

  /* ==========================================================================
     DOM Elements & State
     ========================================================================== */
  const dom = {
    // Canvas & Parallax Elements
    starsContainer: document.getElementById('stars-container'),
    glassOrb: document.getElementById('glass-orb-container'),
    orbGlow: document.getElementById('orb-ambient-glow'),
    geom1: document.getElementById('geom-1'),
    geom2: document.getElementById('geom-2'),
    geom3: document.getElementById('geom-3'),
    geom4: document.getElementById('geom-4'),
    particles: document.getElementById('floating-particles'),
    authCardTilt: document.getElementById('auth-card-tilt-container'),
    authCard: document.getElementById('auth-card'),
    cardSpotlight: document.getElementById('card-spotlight'),
    
    // Forms & Slider
    loginForm: document.getElementById('login-form'),
    signupForm: document.getElementById('signup-form'),
    switchToSignup: document.getElementById('switch-to-signup'),
    switchToLogin: document.getElementById('switch-to-login'),
    
    // Login Inputs & Groups
    loginEmail: document.getElementById('login-email'),
    loginPassword: document.getElementById('login-password'),
    loginEmailGroup: document.getElementById('login-email-group'),
    loginPasswordGroup: document.getElementById('login-password-group'),
    loginEmailError: document.getElementById('login-email-error'),
    loginPasswordError: document.getElementById('login-password-error'),
    loginAlertBanner: document.getElementById('login-alert-banner'),
    loginSubmitBtn: document.getElementById('login-submit-btn'),
    toggleLoginPassword: document.getElementById('toggle-login-password'),
    
    // Signup Inputs & Groups
    signupName: document.getElementById('signup-name'),
    signupEmail: document.getElementById('signup-email'),
    signupPassword: document.getElementById('signup-password'),
    signupConfirmPassword: document.getElementById('signup-confirm-password'),
    signupTerms: document.getElementById('signup-terms'),
    signupNameGroup: document.getElementById('signup-name-group'),
    signupEmailGroup: document.getElementById('signup-email-group'),
    signupPasswordGroup: document.getElementById('signup-password-group'),
    signupConfirmPasswordGroup: document.getElementById('signup-confirm-password-group'),
    signupNameError: document.getElementById('signup-name-error'),
    signupEmailError: document.getElementById('signup-email-error'),
    signupPasswordError: document.getElementById('signup-password-error'),
    signupConfirmError: document.getElementById('signup-confirm-error'),
    signupTermsError: document.getElementById('signup-terms-error'),
    signupAlertBanner: document.getElementById('signup-alert-banner'),
    signupSubmitBtn: document.getElementById('signup-submit-btn'),
    toggleSignupPassword: document.getElementById('toggle-signup-password'),
    toggleSignupConfirm: document.getElementById('toggle-signup-confirm-password'),
    
    // Password Strength Components
    strengthContainer: document.getElementById('password-strength-container'),
    strengthBadge: document.getElementById('strength-badge'),
    strengthFill: document.getElementById('strength-meter-fill'),
    critLength: document.getElementById('crit-length'),
    critUpper: document.getElementById('crit-upper'),
    critNumber: document.getElementById('crit-number'),
    critSymbol: document.getElementById('crit-symbol'),
    
    // Modal & Toast
    forgotModalBackdrop: document.getElementById('forgot-modal-backdrop'),
    forgotPasswordTrigger: document.getElementById('forgot-password-trigger'),
    closeModalBtn: document.getElementById('close-modal-btn'),
    forgotPasswordForm: document.getElementById('forgot-password-form'),
    modalEmailInput: document.getElementById('modal-email-input'),
    modalEmailError: document.getElementById('modal-email-error'),
    modalSubmitBtn: document.getElementById('modal-submit-btn'),
    toastContainer: document.getElementById('toast-container'),
    
    // Social Buttons
    loginGoogleBtn: document.getElementById('login-google-btn'),
    loginGithubBtn: document.getElementById('login-github-btn'),
    signupGoogleBtn: document.getElementById('signup-google-btn'),
    signupGithubBtn: document.getElementById('signup-github-btn'),
    termsLink: document.getElementById('terms-link'),
    privacyLink: document.getElementById('privacy-link'),
  };

  // Parallax Physics State
  const mouseState = {
    x: 0,
    y: 0,
    targetX: 0,
    targetY: 0,
    windowWidth: window.innerWidth,
    windowHeight: window.innerHeight,
    isHoveringCard: false,
    cardRect: null
  };

  /* ==========================================================================
     1. Ambient Star Field Generator
     ========================================================================== */
  function generateStarField() {
    if (!dom.starsContainer) return;
    const starCount = 42;
    const fragment = document.createDocumentFragment();

    for (let i = 0; i < starCount; i++) {
      const star = document.createElement('div');
      star.className = 'star-point';
      
      const posX = Math.random() * 100;
      const posY = Math.random() * 100;
      const size = Math.random() * 2.5 + 1;
      const duration = Math.random() * 3 + 2;
      const delay = Math.random() * 5;

      star.style.left = `${posX}%`;
      star.style.top = `${posY}%`;
      star.style.width = `${size}px`;
      star.style.height = `${size}px`;
      star.style.setProperty('--twinkle-duration', `${duration}s`);
      star.style.animationDelay = `${delay}s`;

      fragment.appendChild(star);
    }

    dom.starsContainer.appendChild(fragment);
  }

  /* ==========================================================================
     2. 60 FPS Mouse Parallax & 3D Tilt Engine (Smooth Linear Interpolation)
     ========================================================================== */
  function initParallaxEngine() {
    // Window Resize Handler
    window.addEventListener('resize', () => {
      mouseState.windowWidth = window.innerWidth;
      mouseState.windowHeight = window.innerHeight;
      updateCardRect();
    }, { passive: true });

    function updateCardRect() {
      if (dom.authCard) {
        mouseState.cardRect = dom.authCard.getBoundingClientRect();
      }
    }
    updateCardRect();

    // Mouse Movement Listener (Normalized coordinates from -1 to 1)
    window.addEventListener('mousemove', (e) => {
      mouseState.targetX = (e.clientX / mouseState.windowWidth) * 2 - 1;
      mouseState.targetY = (e.clientY / mouseState.windowHeight) * 2 - 1;

      // Card Spotlight Coordinate Calculation
      if (dom.authCard && dom.cardSpotlight) {
        const rect = mouseState.cardRect || dom.authCard.getBoundingClientRect();
        const cardX = e.clientX - rect.left;
        const cardY = e.clientY - rect.top;
        dom.cardSpotlight.style.setProperty('--mouse-x', `${cardX}px`);
        dom.cardSpotlight.style.setProperty('--mouse-y', `${cardY}px`);
      }
    }, { passive: true });

    // Smooth Animation Loop using LERP (Linear Interpolation)
    const lerpFactor = 0.065;

    function renderParallaxFrame() {
      // Linear interpolation towards mouse target
      mouseState.x += (mouseState.targetX - mouseState.x) * lerpFactor;
      mouseState.y += (mouseState.targetY - mouseState.y) * lerpFactor;

      const isDesktop = mouseState.windowWidth > 960;

      if (isDesktop) {
        // 3D Orb Parallax
        if (dom.glassOrb) {
          const orbX = mouseState.x * 22;
          const orbY = mouseState.y * 18;
          const orbRotX = -mouseState.y * 12;
          const orbRotY = mouseState.x * 15;
          dom.glassOrb.style.transform = `translate3d(${orbX}px, ${orbY}px, 0px) rotateX(${orbRotX}deg) rotateY(${orbRotY}deg)`;
        }

        // Ambient Glow Parallax
        if (dom.orbGlow) {
          const glowX = mouseState.x * 35;
          const glowY = mouseState.y * 28;
          dom.orbGlow.style.transform = `translate3d(${glowX}px, ${glowY}px, 0px)`;
        }

        // Floating Polyhedra Parallax at varied depths
        if (dom.geom1) {
          dom.geom1.style.transform = `translate3d(${mouseState.x * -28}px, ${mouseState.y * -24}px, 40px)`;
        }
        if (dom.geom2) {
          dom.geom2.style.transform = `translate3d(${mouseState.x * 32}px, ${mouseState.y * -20}px, 20px)`;
        }
        if (dom.geom3) {
          dom.geom3.style.transform = `translate3d(${mouseState.x * -20}px, ${mouseState.y * 22}px, 30px)`;
        }
        if (dom.geom4) {
          dom.geom4.style.transform = `translate3d(${mouseState.x * 24}px, ${mouseState.y * 26}px, 15px)`;
        }

        // Auth Card 3D Tilt
        if (dom.authCardTilt) {
          const cardTiltX = -mouseState.y * 4.5;
          const cardTiltY = mouseState.x * 5.5;
          dom.authCardTilt.style.transform = `perspective(1200px) rotateX(${cardTiltX}deg) rotateY(${cardTiltY}deg)`;
        }
      } else {
        // Reset transforms on mobile screens
        if (dom.glassOrb) dom.glassOrb.style.transform = '';
        if (dom.authCardTilt) dom.authCardTilt.style.transform = '';
      }

      requestAnimationFrame(renderParallaxFrame);
    }

    requestAnimationFrame(renderParallaxFrame);
  }

  /* ==========================================================================
     3. 3D Authentication Mode Switching (Login <-> Signup)
     ========================================================================== */
  function setAuthMode(targetMode) {
    if (!dom.authCard || !dom.loginForm || !dom.signupForm) return;

    // Trigger 3D Card Twist Animation
    dom.authCard.classList.add('card-switching');
    setTimeout(() => {
      dom.authCard.classList.remove('card-switching');
    }, 650);

    // Clear all alerts and errors
    clearAllErrors();

    if (targetMode === 'signup') {
      dom.loginForm.classList.remove('form-active');
      dom.loginForm.classList.add('form-hidden');

      dom.signupForm.classList.remove('form-hidden');
      dom.signupForm.classList.add('form-active');

      setTimeout(() => {
        if (dom.signupName) dom.signupName.focus();
      }, 150);
    } else {
      dom.signupForm.classList.remove('form-active');
      dom.signupForm.classList.add('form-hidden');

      dom.loginForm.classList.remove('form-hidden');
      dom.loginForm.classList.add('form-active');

      setTimeout(() => {
        if (dom.loginEmail) dom.loginEmail.focus();
      }, 150);
    }
  }

  function initModeSwitchers() {
    if (dom.switchToSignup) {
      dom.switchToSignup.addEventListener('click', (e) => {
        e.preventDefault();
        setAuthMode('signup');
      });
    }

    if (dom.switchToLogin) {
      dom.switchToLogin.addEventListener('click', (e) => {
        e.preventDefault();
        setAuthMode('login');
      });
    }
  }

  /* ==========================================================================
     4. Password Visibility Toggle
     ========================================================================== */
  function initPasswordToggles() {
    const toggles = [
      { btn: dom.toggleLoginPassword, input: dom.loginPassword },
      { btn: dom.toggleSignupPassword, input: dom.signupPassword },
      { btn: dom.toggleSignupConfirm, input: dom.signupConfirmPassword }
    ];

    toggles.forEach(({ btn, input }) => {
      if (!btn || !input) return;
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        const isPassword = input.type === 'password';
        input.type = isPassword ? 'text' : 'password';
        btn.classList.toggle('is-visible', isPassword);
        btn.setAttribute('aria-label', isPassword ? 'Hide password' : 'Show password');
      });
    });
  }

  /* ==========================================================================
     5. Real-Time Password Strength Engine
     ========================================================================== */
  function evaluatePasswordStrength(password) {
    let score = 0;
    const checks = {
      length: password.length >= 8,
      upper: /[A-Z]/.test(password) && /[a-z]/.test(password),
      number: /[0-9]/.test(password),
      symbol: /[^A-Za-z0-9]/.test(password)
    };

    if (checks.length) score += 1;
    if (checks.upper) score += 1;
    if (checks.number) score += 1;
    if (checks.symbol) score += 1;

    return { score, checks };
  }

  function updateStrengthUI(password) {
    if (!dom.strengthContainer || !dom.strengthBadge) return;

    if (!password) {
      dom.strengthContainer.className = 'password-strength-container';
      dom.strengthBadge.textContent = 'Enter password';
      if (dom.strengthFill) dom.strengthFill.style.width = '0%';
      [dom.critLength, dom.critUpper, dom.critNumber, dom.critSymbol].forEach(el => {
        if (el) el.classList.remove('crit-met');
      });
      return;
    }

    const { score, checks } = evaluatePasswordStrength(password);

    // Update Criteria Pills
    if (dom.critLength) dom.critLength.classList.toggle('crit-met', checks.length);
    if (dom.critUpper) dom.critUpper.classList.toggle('crit-met', checks.upper);
    if (dom.critNumber) dom.critNumber.classList.toggle('crit-met', checks.number);
    if (dom.critSymbol) dom.critSymbol.classList.toggle('crit-met', checks.symbol);

    // Update Strength Bar & Label
    dom.strengthContainer.className = 'password-strength-container';

    if (score <= 1) {
      dom.strengthContainer.classList.add('strength-weak');
      dom.strengthBadge.textContent = 'Weak';
    } else if (score === 2) {
      dom.strengthContainer.classList.add('strength-fair');
      dom.strengthBadge.textContent = 'Fair';
    } else if (score === 3) {
      dom.strengthContainer.classList.add('strength-good');
      dom.strengthBadge.textContent = 'Good';
    } else if (score >= 4) {
      dom.strengthContainer.classList.add('strength-strong');
      dom.strengthBadge.textContent = 'Strong';
    }
  }

  function initPasswordStrengthListener() {
    if (dom.signupPassword) {
      dom.signupPassword.addEventListener('input', (e) => {
        updateStrengthUI(e.target.value);
        if (dom.signupPasswordGroup.classList.contains('is-invalid')) {
          validateField(dom.signupPassword, dom.signupPasswordGroup, dom.signupPasswordError, validateSignupPassword);
        }
      });
    }
  }

  /* ==========================================================================
     6. Validation Helpers & Input Error Management
     ========================================================================== */
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  function showFieldError(groupEl, errorEl, message) {
    if (groupEl) {
      groupEl.classList.remove('is-valid');
      groupEl.classList.add('is-invalid');
    }
    if (errorEl) {
      errorEl.textContent = message;
      errorEl.style.display = 'block';
    }
  }

  function clearFieldError(groupEl, errorEl) {
    if (groupEl) {
      groupEl.classList.remove('is-invalid');
      groupEl.classList.add('is-valid');
    }
    if (errorEl) {
      errorEl.textContent = '';
      errorEl.style.display = 'none';
    }
  }

  function resetFieldState(groupEl, errorEl) {
    if (groupEl) {
      groupEl.classList.remove('is-invalid', 'is-valid');
    }
    if (errorEl) {
      errorEl.textContent = '';
      errorEl.style.display = 'none';
    }
  }

  function clearAllErrors() {
    const groups = [
      dom.loginEmailGroup, dom.loginPasswordGroup,
      dom.signupNameGroup, dom.signupEmailGroup,
      dom.signupPasswordGroup, dom.signupConfirmPasswordGroup
    ];
    const errors = [
      dom.loginEmailError, dom.loginPasswordError,
      dom.signupNameError, dom.signupEmailError,
      dom.signupPasswordError, dom.signupConfirmError,
      dom.signupTermsError
    ];

    groups.forEach(g => { if (g) g.classList.remove('is-invalid', 'is-valid'); });
    errors.forEach(e => { if (e) { e.textContent = ''; e.style.display = 'none'; } });

    if (dom.loginAlertBanner) dom.loginAlertBanner.className = 'form-alert-banner';
    if (dom.signupAlertBanner) dom.signupAlertBanner.className = 'form-alert-banner';
  }

  function validateEmail(val) {
    if (!val || !val.trim()) return 'Email address is required';
    if (!emailRegex.test(val.trim())) return 'Please provide a valid email format (e.g. name@domain.com)';
    return null;
  }

  function validateLoginPassword(val) {
    if (!val) return 'Password is required';
    if (val.length < 6) return 'Password must be at least 6 characters';
    return null;
  }

  function validateSignupName(val) {
    if (!val || !val.trim()) return 'Full name is required';
    if (val.trim().length < 2) return 'Please enter at least 2 characters';
    return null;
  }

  function validateSignupPassword(val) {
    if (!val) return 'Password is required';
    if (val.length < 8) return 'Password must be at least 8 characters';
    const { score } = evaluatePasswordStrength(val);
    if (score < 2) return 'Password is too simple. Add uppercase, numbers, or symbols';
    return null;
  }

  function validateConfirmPassword(confirmVal, originalVal) {
    if (!confirmVal) return 'Please confirm your password';
    if (confirmVal !== originalVal) return 'Passwords do not match';
    return null;
  }

  function validateField(inputEl, groupEl, errorEl, validatorFn, secondaryVal) {
    const errorMsg = validatorFn(inputEl.value, secondaryVal);
    if (errorMsg) {
      showFieldError(groupEl, errorEl, errorMsg);
      return false;
    } else {
      clearFieldError(groupEl, errorEl);
      return true;
    }
  }

  /* Attach Real-time Input Listeners */
  function initInputValidationListeners() {
    // Login Email
    if (dom.loginEmail) {
      dom.loginEmail.addEventListener('blur', () => {
        validateField(dom.loginEmail, dom.loginEmailGroup, dom.loginEmailError, validateEmail);
      });
      dom.loginEmail.addEventListener('input', () => {
        if (dom.loginEmailGroup.classList.contains('is-invalid')) {
          validateField(dom.loginEmail, dom.loginEmailGroup, dom.loginEmailError, validateEmail);
        }
      });
    }

    // Login Password
    if (dom.loginPassword) {
      dom.loginPassword.addEventListener('blur', () => {
        validateField(dom.loginPassword, dom.loginPasswordGroup, dom.loginPasswordError, validateLoginPassword);
      });
      dom.loginPassword.addEventListener('input', () => {
        if (dom.loginPasswordGroup.classList.contains('is-invalid')) {
          validateField(dom.loginPassword, dom.loginPasswordGroup, dom.loginPasswordError, validateLoginPassword);
        }
      });
    }

    // Signup Name
    if (dom.signupName) {
      dom.signupName.addEventListener('blur', () => {
        validateField(dom.signupName, dom.signupNameGroup, dom.signupNameError, validateSignupName);
      });
      dom.signupName.addEventListener('input', () => {
        if (dom.signupNameGroup.classList.contains('is-invalid')) {
          validateField(dom.signupName, dom.signupNameGroup, dom.signupNameError, validateSignupName);
        }
      });
    }

    // Signup Email
    if (dom.signupEmail) {
      dom.signupEmail.addEventListener('blur', () => {
        validateField(dom.signupEmail, dom.signupEmailGroup, dom.signupEmailError, validateEmail);
      });
      dom.signupEmail.addEventListener('input', () => {
        if (dom.signupEmailGroup.classList.contains('is-invalid')) {
          validateField(dom.signupEmail, dom.signupEmailGroup, dom.signupEmailError, validateEmail);
        }
      });
    }

    // Signup Confirm Password
    if (dom.signupConfirmPassword) {
      dom.signupConfirmPassword.addEventListener('blur', () => {
        validateField(dom.signupConfirmPassword, dom.signupConfirmPasswordGroup, dom.signupConfirmError, validateConfirmPassword, dom.signupPassword.value);
      });
      dom.signupConfirmPassword.addEventListener('input', () => {
        if (dom.signupConfirmPasswordGroup.classList.contains('is-invalid')) {
          validateField(dom.signupConfirmPassword, dom.signupConfirmPasswordGroup, dom.signupConfirmError, validateConfirmPassword, dom.signupPassword.value);
        }
      });
    }

    // Signup Terms Checkbox
    if (dom.signupTerms) {
      dom.signupTerms.addEventListener('change', () => {
        if (dom.signupTerms.checked) {
          dom.signupTermsError.style.display = 'none';
        }
      });
    }
  }

  /* ==========================================================================
     7. Toast Notification Utility
     ========================================================================== */
  function showToast(message, type = 'success', duration = 4000) {
    if (!dom.toastContainer) return;

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;

    const iconSvg = type === 'success'
      ? `<svg class="toast-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#10b981" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>`
      : `<svg class="toast-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#f43f5e" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>`;

    toast.innerHTML = `
      ${iconSvg}
      <span class="toast-message">${message}</span>
    `;

    dom.toastContainer.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateX(40px)';
      setTimeout(() => {
        if (toast.parentNode) toast.parentNode.removeChild(toast);
      }, 300);
    }, duration);
  }

  /* ==========================================================================
     8. Form Submission Handlers (Async Simulation & Feedback)
     ========================================================================== */
  function initFormSubmissions() {
    // Login Submit Handler
    if (dom.loginForm) {
      dom.loginForm.addEventListener('submit', (e) => {
        e.preventDefault();

        const isEmailValid = validateField(dom.loginEmail, dom.loginEmailGroup, dom.loginEmailError, validateEmail);
        const isPasswordValid = validateField(dom.loginPassword, dom.loginPasswordGroup, dom.loginPasswordError, validateLoginPassword);

        if (!isEmailValid || !isPasswordValid) {
          if (dom.loginAlertBanner) {
            dom.loginAlertBanner.className = 'form-alert-banner alert-error';
            dom.loginAlertBanner.querySelector('.alert-message').textContent = 'Please resolve the highlighted errors before submitting.';
          }
          return;
        }

        // Disable banner error
        if (dom.loginAlertBanner) dom.loginAlertBanner.className = 'form-alert-banner';

        // Set Button Loading State
        dom.loginSubmitBtn.classList.add('is-loading');

        // Simulate Async Network Request
        setTimeout(() => {
          dom.loginSubmitBtn.classList.remove('is-loading');

          const rememberText = document.getElementById('login-remember')?.checked ? ' (Device remembered)' : '';
          showToast(`Welcome back, ${dom.loginEmail.value.split('@')[0]}! Initializing quantum session...${rememberText}`, 'success');

          if (dom.loginAlertBanner) {
            dom.loginAlertBanner.className = 'form-alert-banner alert-success';
            dom.loginAlertBanner.querySelector('.alert-message').textContent = 'Authentication verified! Redirecting to workspace...';
          }
        }, 1200);
      });
    }

    // Signup Submit Handler
    if (dom.signupForm) {
      dom.signupForm.addEventListener('submit', (e) => {
        e.preventDefault();

        const isNameValid = validateField(dom.signupName, dom.signupNameGroup, dom.signupNameError, validateSignupName);
        const isEmailValid = validateField(dom.signupEmail, dom.signupEmailGroup, dom.signupEmailError, validateEmail);
        const isPasswordValid = validateField(dom.signupPassword, dom.signupPasswordGroup, dom.signupPasswordError, validateSignupPassword);
        const isConfirmValid = validateField(dom.signupConfirmPassword, dom.signupConfirmPasswordGroup, dom.signupConfirmError, validateConfirmPassword, dom.signupPassword.value);
        
        let isTermsValid = true;
        if (!dom.signupTerms.checked) {
          dom.signupTermsError.textContent = 'You must accept the Terms & Conditions to proceed';
          dom.signupTermsError.style.display = 'block';
          isTermsValid = false;
        } else {
          dom.signupTermsError.style.display = 'none';
        }

        if (!isNameValid || !isEmailValid || !isPasswordValid || !isConfirmValid || !isTermsValid) {
          if (dom.signupAlertBanner) {
            dom.signupAlertBanner.className = 'form-alert-banner alert-error';
            dom.signupAlertBanner.querySelector('.alert-message').textContent = 'Please complete all required fields accurately.';
          }
          return;
        }

        // Disable banner error
        if (dom.signupAlertBanner) dom.signupAlertBanner.className = 'form-alert-banner';

        // Set Button Loading State
        dom.signupSubmitBtn.classList.add('is-loading');

        // Simulate Async Registration
        setTimeout(() => {
          dom.signupSubmitBtn.classList.remove('is-loading');

          showToast(`Account successfully provisioned for ${dom.signupName.value}! Welcome aboard.`, 'success');

          if (dom.signupAlertBanner) {
            dom.signupAlertBanner.className = 'form-alert-banner alert-success';
            dom.signupAlertBanner.querySelector('.alert-message').textContent = 'Account created! Switching to login...';
          }

          setTimeout(() => {
            setAuthMode('login');
            dom.loginEmail.value = dom.signupEmail.value;
            dom.loginPassword.value = '';
            clearAllErrors();
          }, 1500);
        }, 1300);
      });
    }
  }

  /* ==========================================================================
     9. Forgot Password Modal & Social Login Handlers
     ========================================================================== */
  function initModalAndSocials() {
    // Open Forgot Password Modal
    if (dom.forgotPasswordTrigger && dom.forgotModalBackdrop) {
      dom.forgotPasswordTrigger.addEventListener('click', (e) => {
        e.preventDefault();
        dom.forgotModalBackdrop.removeAttribute('hidden');
        if (dom.modalEmailInput) {
          dom.modalEmailInput.value = dom.loginEmail?.value || '';
          dom.modalEmailInput.focus();
        }
      });
    }

    // Close Modal
    function closeModal() {
      if (dom.forgotModalBackdrop) {
        dom.forgotModalBackdrop.setAttribute('hidden', '');
        if (dom.modalEmailError) dom.modalEmailError.style.display = 'none';
      }
    }

    if (dom.closeModalBtn) {
      dom.closeModalBtn.addEventListener('click', closeModal);
    }

    if (dom.forgotModalBackdrop) {
      dom.forgotModalBackdrop.addEventListener('click', (e) => {
        if (e.target === dom.forgotModalBackdrop) closeModal();
      });
    }

    // Escape Key Listener
    window.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && dom.forgotModalBackdrop && !dom.forgotModalBackdrop.hasAttribute('hidden')) {
        closeModal();
      }
    });

    // Forgot Password Submit
    if (dom.forgotPasswordForm) {
      dom.forgotPasswordForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const emailVal = dom.modalEmailInput.value;
        const err = validateEmail(emailVal);

        if (err) {
          if (dom.modalEmailError) {
            dom.modalEmailError.textContent = err;
            dom.modalEmailError.style.display = 'block';
          }
          return;
        }

        if (dom.modalSubmitBtn) dom.modalSubmitBtn.classList.add('is-loading');

        setTimeout(() => {
          if (dom.modalSubmitBtn) dom.modalSubmitBtn.classList.remove('is-loading');
          closeModal();
          showToast(`Encrypted reset token dispatched to ${emailVal}`, 'success', 5000);
        }, 1000);
      });
    }

    // Social Login Simulations
    const socialButtons = [
      { el: dom.loginGoogleBtn, provider: 'Google' },
      { el: dom.loginGithubBtn, provider: 'GitHub' },
      { el: dom.signupGoogleBtn, provider: 'Google' },
      { el: dom.signupGithubBtn, provider: 'GitHub' }
    ];

    socialButtons.forEach(({ el, provider }) => {
      if (!el) return;
      el.addEventListener('click', (e) => {
        e.preventDefault();
        showToast(`Connecting to ${provider} OAuth Gateway...`, 'success', 3000);
      });
    });

    // Terms & Privacy Links
    if (dom.termsLink) {
      dom.termsLink.addEventListener('click', (e) => {
        e.preventDefault();
        showToast('NEURA Terms of Service: Zero-trust data privacy policy is standard.', 'success');
      });
    }

    if (dom.privacyLink) {
      dom.privacyLink.addEventListener('click', (e) => {
        e.preventDefault();
        showToast('NEURA Privacy Policy: Client telemetry is end-to-end encrypted.', 'success');
      });
    }
  }

  /* ==========================================================================
     10. Bootstrap Initialization
     ========================================================================== */
  function init() {
    generateStarField();
    initParallaxEngine();
    initModeSwitchers();
    initPasswordToggles();
    initPasswordStrengthListener();
    initInputValidationListeners();
    initFormSubmissions();
    initModalAndSocials();
  }

  // Ensure DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();
